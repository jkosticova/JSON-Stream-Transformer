package Prototype.StateArchitecture.State;

import Prototype.PathAutomaton.PathAutomaton;
import Prototype.SpecificationParser.TransformationFormat;
import Prototype.StateArchitecture.Transducer.Transducer;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import java.io.IOException;
import java.util.Stack;



public class Eval implements State {
    Transducer transducer;
    private JsonGenerator generator;
    private Stack<Integer> paStack;
    private Stack<Integer> indexStack;
    private TransformationFormat specification;
    private PathAutomaton pa;

    public Eval(Transducer transducer) {
        this.transducer = transducer;
        init();
    }

    private void init() {
        this.generator = this.transducer.getGenerator();
        this.paStack = this.transducer.getPaStack();
        this.indexStack = this.transducer.getIndexStack();
        this.specification = this.transducer.getSpecification();
        this.pa = this.transducer.getPa();
    }

    public void process(JsonToken event, JsonParser parser) {
        int paState;                
        try {
            init();

            switch (event) {
                case START_ARRAY:                    
                    if (paStack.peek().equals(ARR_MARKER)) {
                        Integer i = indexStack.pop();
                        paStack.pop(); // pop ARR_MARKER
                        paState = paStack.peek();
                        paStack.push(ARR_MARKER); // push ARR_MARKER back
                        paStack.push(pa.transition(paState, i.toString()));                        
                        indexStack.push(i + 1);
                    }

                    if (pa.isFinal(paStack.peek())) {
                        transducer.setState(transducer.getMatchState());
                        transducer.setPaused(true);
                        indexStack.push(0);
                        paStack.push(ARR_MARKER);
                        return;
                    }

                    indexStack.push(0);
                    paStack.push(ARR_MARKER);

                    break;
                case END_ARRAY:
                    indexStack.pop();

                    paStack.pop();
                    paStack.pop();

                    break;
                case START_OBJECT:
                    if (paStack.peek().equals(ARR_MARKER)) {
                        Integer i = indexStack.pop();
                        paStack.pop(); // pop ARR_MARKER
                        paState = paStack.peek();
                        paStack.push(ARR_MARKER); // push ARR_MARKER back
                        paStack.push(pa.transition(paState, i.toString()));                        
                        indexStack.push(i + 1);
                    }

                    if (pa.isFinal(paStack.peek())) {
                        transducer.setState(transducer.getMatchState());
                        transducer.setPaused(true);
                        paStack.push(OBJ_MARKER);
                        return;
                    }

                    paStack.push(OBJ_MARKER);

                    break;
                case END_OBJECT:
                    if (!paStack.peek().equals(ARR_MARKER)) {
                        paStack.pop();
                    }
                    if (!paStack.peek().equals(ARR_MARKER)) {
                        paStack.pop();
                    }

                    break;
                case FIELD_NAME:
                    // field name after start object or start array
                    if (paStack.peek() < 0) {
                        int marker = paStack.pop(); // pop OBJ_MARKER
                        paState = paStack.peek();
                        paStack.push(marker); // push OBJ_MARKER back
                    }
                    // field name within object
                    else {
                        paState = paStack.peek();
                    }
                    paStack.push(pa.transition(paState, parser.getParsingContext().getCurrentName()));

                    if (pa.isFinal(paStack.peek())) {
                        transducer.setState(transducer.getMatchState());
                        transducer.setPaused(true);
                        return;
                    }

                    break;
                case VALUE_FALSE:
                case VALUE_NULL:
                case VALUE_TRUE:
                case VALUE_STRING:
                case VALUE_NUMBER_INT:
                case VALUE_NUMBER_FLOAT:
                    if (paStack.peek().equals(ARR_MARKER)) {
                        Integer i = indexStack.pop();
                        paStack.pop(); // pop ARR_MARKER
                        paState = paStack.peek();
                        paStack.push(ARR_MARKER); // push ARR_MARKER back
                        paStack.push(pa.transition(paState, i.toString()));
                        indexStack.push(i + 1);
                    }

                    if (pa.isFinal(paStack.peek())) {
                        transducer.setState(transducer.getMatchState());
                        transducer.setPaused(true);
                        return;
                    }

                    paStack.pop(); // pop new state in case of array or fieldname
                    break;
            }

            if (this.transducer.isGenerating()) {
                generator.copyCurrentEvent(parser);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
