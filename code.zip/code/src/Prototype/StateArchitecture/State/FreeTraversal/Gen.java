package Prototype.StateArchitecture.State.FreeTraversal;

import Prototype.StateArchitecture.State.State;
import Prototype.StateArchitecture.Transducer.Transducer;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;



/*
    This state copies the input event to the output.
    It does not manipulate the stack in case of stack transducer
*/
public class Gen implements State {
    private final Transducer transducer;    

    public Gen(Transducer transducer) {
        this.transducer = transducer;    
    }

    @Override
    public void process(JsonParser parser) {
        transducer.setPaused(false);    
        transducer.setGenerating(true);
    }
    

}
